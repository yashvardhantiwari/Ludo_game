﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RollingDice : MonoBehaviour
{
    [SerializeField] int numberGot;
    [SerializeField] GameObject RollingDiceAnim;
    [SerializeField] SpriteRenderer NumberedSpriteHolder;
    [SerializeField] Sprite[] numberedSprites;

    bool canDiceRoll = true;
    Coroutine GenerateRandomNumberOnDice_Coroutine;
    private void OnMouseDown()
    {
        GenerateRandomNumberOnDice_Coroutine = StartCoroutine(GenerateRandomNumberOnDice_Enum());
    }

    IEnumerator GenerateRandomNumberOnDice_Enum()
    {
        yield return new WaitForEndOfFrame();
        if (canDiceRoll)
        {
            canDiceRoll = false;
            NumberedSpriteHolder.gameObject.SetActive(false);
            RollingDiceAnim.SetActive(true);

            yield return new WaitForSeconds(1f);
            numberGot = Random.Range(0, 6);
            NumberedSpriteHolder.sprite = numberedSprites[numberGot];
            numberGot += 1;

            GameManager.gm.numOfStepsToMove = numberGot;
            GameManager.gm.rolledDice = this;

            NumberedSpriteHolder.gameObject.SetActive(true);
            RollingDiceAnim.SetActive(false);
            yield return new WaitForEndOfFrame();
            canDiceRoll = true;
            if (GenerateRandomNumberOnDice_Coroutine != null)
            {
                StopCoroutine(GenerateRandomNumberOnDice_Coroutine);
            }
        }

    }
}