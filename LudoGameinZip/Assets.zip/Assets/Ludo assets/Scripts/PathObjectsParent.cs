﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathObjectsParent : MonoBehaviour
{
    public PathPoint[] CommonPath;
    public PathPoint[] GreendesigPath;
    public PathPoint[] YellowdesigPahth;
    public PathPoint[] BluedesigPath;
    public PathPoint[] ReddesigPath;
} 
