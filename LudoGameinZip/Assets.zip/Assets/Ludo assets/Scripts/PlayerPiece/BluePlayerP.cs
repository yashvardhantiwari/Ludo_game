﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BluePlayerP : PlayerP
{

    RollingDice BlueHomeRollingDice;
    private void Start()
    {
        BlueHomeRollingDice = GetComponentInParent<BlueHome>().rollingDice;
    }
    private void OnMouseDown()
    {
        if (GameManager.gm.rolledDice != null && GameManager.gm.rolledDice == BlueHomeRollingDice)
        {
               canMove = true;
        }
     
        MoveSteps();
    }
}